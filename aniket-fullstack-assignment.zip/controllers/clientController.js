
const { pool: db } = require('../config/db');

exports.getAllClients = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM clients ORDER BY created_at DESC');
        res.render('admin/clients_list', { clients: rows, title: 'Manage Clients' });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
};

exports.getAddClient = (req, res) => {
    res.render('admin/client_add', { title: 'Add Client' });
};

exports.createClient = async (req, res) => {
    const { name, designation, description, image_path } = req.body;
    try {
        await db.query('INSERT INTO clients (name, designation, description, image_path) VALUES (?, ?, ?, ?)',
            [name, designation, description, image_path]);
        res.redirect('/admin/clients');
    } catch (err) {
        console.error(err);
        res.status(500).send('Error adding client');
    }
};

exports.deleteClient = async (req, res) => {
    const { id } = req.params;
    try {
        await db.query('DELETE FROM clients WHERE id = ?', [id]);
        res.redirect('/admin/clients');
    } catch (err) {
        console.error(err);
        res.status(500).send('Error deleting client');
    }
};
