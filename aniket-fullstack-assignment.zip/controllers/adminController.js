
const { pool: db } = require('../config/db');

exports.getContacts = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM contact_forms ORDER BY submitted_at DESC');
        res.render('admin/contact_list', { contacts: rows, title: 'Contact Submissions' });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
};

exports.getNewsletter = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM newsletter ORDER BY subscribed_at DESC');
        res.render('admin/newsletter_list', { subscribers: rows, title: 'Newsletter Subscribers' });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
};
