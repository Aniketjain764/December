
const { pool: db } = require('../config/db');

exports.getHomePage = async (req, res) => {
    try {
        const [projects] = await db.query('SELECT * FROM projects ORDER BY created_at DESC LIMIT 4');
        const [clients] = await db.query('SELECT * FROM clients ORDER BY created_at DESC LIMIT 4');
        res.render('index', { title: 'Home', projects, clients });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
};

exports.submitContact = async (req, res) => {
    const { name, email, mobile, city, message } = req.body;
    try {
        await db.query('INSERT INTO contact_forms (name, email, mobile, city, message) VALUES (?, ?, ?, ?, ?)',
            [name, email, mobile, city, message]);
        res.render('index', { title: 'Home', message: 'Message sent successfully!' });
    } catch (err) {
        console.error(err);
        res.status(500).render('index', { title: 'Home', error: 'Server Error' });
    }
};

exports.subscribeNewsletter = async (req, res) => {
    const { email } = req.body;
    try {
        await db.query('INSERT INTO newsletter (email) VALUES (?)', [email]);
        res.render('index', { title: 'Home', message: 'Subscribed successfully!' });
    } catch (err) {
        console.error(err);
        if (err.code === 'ER_DUP_ENTRY') {
            res.render('index', { title: 'Home', message: 'Already subscribed!' });
        } else {
            res.status(500).render('index', { title: 'Home', error: 'Server Error' });
        }
    }
};
