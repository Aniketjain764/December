const express = require('express');
const router = express.Router();
const { pool: db } = require('../config/db');

const publicController = require('../controllers/publicController');

router.get('/', publicController.getHomePage);

router.post('/contact', publicController.submitContact);
router.post('/newsletter', publicController.subscribeNewsletter);

router.get('/test-db', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT 1 + 1 AS solution');
        res.json({ message: 'Database connection successful', result: rows[0].solution });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Database connection failed', error: err.message });
    }
});

module.exports = router;
